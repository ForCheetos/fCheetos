Author: Lensly 
License: Free for personal use.

This teleport pack was created specifically for the UNI EMPIRE Discord community and the Unicore client for Genshin Impact.

Features:
- Full Coverage: Includes almost all in-game regions.
- Superior Optimization: Enhanced performance and stability compared to other existing packs.

Terms of Use:
This pack is created for the community and is strictly FREE OF CHARGE.

- No Commercial Use: You are not allowed to sell, lease, or monetize this pack or any of its components.
- No Redistribution for Profit: Do not include these files in paid assemblies, stores, or "VIP" access tiers.
- Credits: If you feature this pack in your project or video, please provide credit to the author (Lensly) and the Unicore project.

If you paid for this pack, you have been scammed. Support the creator by respecting these rules.

Have a great game!